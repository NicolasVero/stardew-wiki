<?php 

require_once 'includes/functions/utility_functions.php';
require_once 'includes/functions/data_functions.php';
require_once 'includes/functions/display_functions.php';
