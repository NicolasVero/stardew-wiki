<?php

require 'functions.php';

include 'components/header.php';

echo display_landing_page();

include 'components/footer.php';